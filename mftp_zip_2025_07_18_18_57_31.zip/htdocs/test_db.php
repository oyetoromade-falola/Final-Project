<?php
include 'db.php';
echo "✅ Connected to database successfully!";
?>
