<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login - COURSEMART FCFMT</title>
  <link rel="stylesheet" href="css/style.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    html, body { height: 100%; margin: 0; }
    body {
      display: flex;
      flex-direction: column;
      background-color: #f4f7fa;
    }
    main { flex: 1; }
    .login-container {
      max-width: 420px;
      margin: 5rem auto;
      padding: 2rem;
      background-color: #ffffff;
      border-radius: 10px;
      box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.05);
    }
    .form-title {
      color: #007bff;
      font-weight: 600;
      text-align: center;
      margin-bottom: 1.5rem;
    }
    .form-control { border-radius: 6px; }
    .btn-primary { border-radius: 6px; }
    .logo {
      width: 60px;
      display: block;
      margin: 0 auto 1rem auto;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="img/coursemart-logo.png" alt="Logo" width="40" height="40" />
      COURSEMART FCFMT
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="about.html">About</a></li>
        <li class="nav-item"><a class="nav-link" href="courses.html">Courses</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.html">Contact</a></li>
        <li class="nav-item"><a class="nav-link" href="faq_testimonials.html">FAQs</a></li>
        <li class="nav-item"><a class="nav-link active" href="login.html">Login</a></li>
        <li class="nav-item"><a class="nav-link" href="signup.html">Sign Up</a></li>
      </ul>
    </div>
  </div>
</nav>

<main>
  <div class="login-container">
    <img src="img/coursemart-logo.png" alt="Logo" class="logo">
    <h4 class="form-title">User Login</h4>
    
    <!-- Updated Form: POSTs to login.php -->
    <form action="login.php" method="POST">
      <div class="mb-3">
        <label for="email" class="form-label">Email address</label>
        <input type="email" id="email" name="email" class="form-control" placeholder="you@example.com" required />
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" id="password" name="password" class="form-control" placeholder="Enter password" required />
      </div>
      <div class="mb-3 form-check">
        <input type="checkbox" id="remember" name="remember" class="form-check-input">
        <label class="form-check-label" for="remember">Remember me</label>
      </div>
      <button type="submit" class="btn btn-primary w-100">Login</button>
      <div class="mt-3 text-center">
        <small>Don't have an account? <a href="signup.html">Sign up</a></small>
      </div>
    </form>
  </div>
</main>

<!-- Footer -->
<footer class="text-center text-white bg-dark py-3">
  <p>
    <span class="footer-highlight">&copy; 2025 COURSEMART FCFMT</span> | 
    <span class="footer-credit">Designed by <strong>Falola Regina</strong></span>
  </p>
  <p>
    <a href="contact.html" class="footer-link">Contact</a> |
    <a href="about.html" class="footer-link">About</a>
  </p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
